<?php defined('BASEPATH') OR exit('No direct script access allowed.');

	if ( ! function_exists('count_visitor')) {
    function count_visitor()
    {

    }
}