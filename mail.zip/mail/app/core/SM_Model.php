<?php
class SM_Model extends CI_Model
{
	
}