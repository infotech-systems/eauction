<?php
class SM_Controller extends CI_Controller
{
	//public $count_visitor;
	public function __construct()
    {
        parent::__construct();
      //  $this->load->helper('counter');
      //  $this->count_visitor = count_visitor();
    }   
	
	
}